export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Método não permitido." });
  }

  try {
    const data = typeof req.body === "string" ? JSON.parse(req.body) : req.body;

    if (data.website) {
      return res.status(200).json({ ok: true });
    }

    const required = ["nome", "email", "servico", "mensagem", "consentimento"];
    for (const field of required) {
      if (!data[field]) {
        return res.status(400).json({ error: "Preencha os campos obrigatórios." });
      }
    }

    if (!process.env.RESEND_API_KEY || !process.env.CONTACT_EMAIL) {
      return res.status(503).json({ error: "Formulário ainda não configurado." });
    }

    const clean = (value = "") =>
      String(value).replace(/[<>&"]/g, (char) => ({
        "<": "&lt;",
        ">": "&gt;",
        "&": "&amp;",
        '"': "&quot;"
      }[char]));

    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: process.env.FROM_EMAIL || "PAYOUT Site <onboarding@resend.dev>",
        to: [process.env.CONTACT_EMAIL],
        reply_to: data.email,
        subject: `Novo contato — ${clean(data.servico)}`,
        html: `
          <h2>Novo contato pelo site</h2>
          <p><b>Nome:</b> ${clean(data.nome)}</p>
          <p><b>E-mail:</b> ${clean(data.email)}</p>
          <p><b>Telefone:</b> ${clean(data.telefone)}</p>
          <p><b>Cidade:</b> ${clean(data.cidade)}</p>
          <p><b>Serviço:</b> ${clean(data.servico)}</p>
          <p><b>Mensagem:</b><br>${clean(data.mensagem).replace(/\n/g, "<br>")}</p>
        `
      })
    });

    if (!response.ok) {
      return res.status(502).json({ error: "Falha no serviço de e-mail." });
    }

    return res.status(200).json({ ok: true });
  } catch {
    return res.status(400).json({ error: "Solicitação inválida." });
  }
}
